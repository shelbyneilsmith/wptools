<div id="pagination" class="clearfix">
	<?php yb_pagination(); ?>
	<?php //yb_pagination_2(); ?>
</div>
<p class="hidden"><?php posts_nav_link(); ?></p>